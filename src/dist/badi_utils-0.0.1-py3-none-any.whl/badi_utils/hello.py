def hello():
    print("Hello, Badi utils working...")


hello()
