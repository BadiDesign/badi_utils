# Badi Utils

This is a package of utils. You can use
[BadiUtils github](https://github.com/BadiDesign/badi_utils)
to write your content.
